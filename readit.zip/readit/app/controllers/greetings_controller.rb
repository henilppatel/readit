class GreetingsController < ApplicationController
  def hello
  end
end
